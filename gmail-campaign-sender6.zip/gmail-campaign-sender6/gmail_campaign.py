"""
Gmail Campaign Sender
Sends personalized HTML email campaigns from a CSV contact list via Gmail API with OAuth2.
"""

import os
import csv
import json
import base64
import logging
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

BASE_DIR = Path(__file__).parent
CREDENTIALS_FILE = BASE_DIR / "credentials.json"
TOKEN_FILE = BASE_DIR / "token.json"
CONTACTS_CSV = BASE_DIR / "contacts.csv"
TEMPLATE_FILE = BASE_DIR / "email_template.html"
ATTACHMENTS_DIR = BASE_DIR / "attachments"
LOG_FILE = BASE_DIR / "send_log.csv"

SENDER_NAME = "Your Company"      # Change to your name / company
SUBJECT = "A personalized message for {name} at {company}"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# --------------------------------------------------------------------------- #
# OAuth2 authentication
# --------------------------------------------------------------------------- #


def get_gmail_service():
    """Authenticate with Gmail API and return an authorized service object."""
    creds = None

    if TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not CREDENTIALS_FILE.exists():
                raise FileNotFoundError(
                    f"credentials.json not found at {CREDENTIALS_FILE}\n"
                    "Download it from Google Cloud Console → APIs & Services → Credentials."
                )
            flow = InstalledAppFlow.from_client_secrets_file(
                str(CREDENTIALS_FILE), SCOPES
            )
            creds = flow.run_local_server(port=0)

        with open(TOKEN_FILE, "w") as f:
            f.write(creds.to_json())
        log.info("Token saved to %s", TOKEN_FILE)

    return build("gmail", "v1", credentials=creds)


# --------------------------------------------------------------------------- #
# CSV helpers
# --------------------------------------------------------------------------- #


def load_contacts(csv_path: Path) -> list[dict]:
    """Load contacts from CSV. Required columns: email, name, company."""
    contacts = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row = {k.strip().lower(): v.strip() for k, v in row.items()}
            if not row.get("email"):
                log.warning("Skipping row without email: %s", row)
                continue
            contacts.append(row)
    log.info("Loaded %d contacts from %s", len(contacts), csv_path)
    return contacts


def load_log(log_path: Path) -> set[str]:
    """Return the set of emails that were already sent successfully."""
    sent = set()
    if not log_path.exists():
        return sent
    with open(log_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("status") == "sent":
                sent.add(row["email"].strip().lower())
    return sent


def append_log(log_path: Path, record: dict):
    """Append a result row to the send log CSV."""
    fieldnames = ["timestamp", "email", "name", "company", "subject", "attachment", "status", "error"]
    write_header = not log_path.exists()
    with open(log_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerow(record)


# --------------------------------------------------------------------------- #
# Template rendering
# --------------------------------------------------------------------------- #


def render_template(template: str, contact: dict) -> str:
    """
    Replace {{variable}} placeholders in the template with contact values.
    Supported variables: name, company, email, plus any extra CSV columns.
    """
    result = template
    for key, value in contact.items():
        result = result.replace("{{" + key + "}}", value)
    return result


# --------------------------------------------------------------------------- #
# Email builder
# --------------------------------------------------------------------------- #


def build_message(
    sender_email: str,
    contact: dict,
    html_body: str,
    subject: str,
    pdf_path: Path | None,
) -> dict:
    """Build a Gmail API-compatible raw message dict."""
    msg = MIMEMultipart("mixed")
    msg["From"] = f"{SENDER_NAME} <{sender_email}>"
    msg["To"] = contact["email"]
    msg["Subject"] = subject

    # HTML + plain-text fallback
    alt = MIMEMultipart("alternative")
    plain = html_body.replace("<br>", "\n").replace("<br/>", "\n")
    # Strip remaining HTML tags crudely for plain-text fallback
    import re
    plain = re.sub(r"<[^>]+>", "", plain).strip()
    alt.attach(MIMEText(plain, "plain", "utf-8"))
    alt.attach(MIMEText(html_body, "html", "utf-8"))
    msg.attach(alt)

    # Optional PDF attachment
    if pdf_path and pdf_path.exists():
        with open(pdf_path, "rb") as f:
            attachment = MIMEApplication(f.read(), _subtype="pdf")
            attachment.add_header(
                "Content-Disposition", "attachment", filename=pdf_path.name
            )
            msg.attach(attachment)

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    return {"raw": raw}


# --------------------------------------------------------------------------- #
# Campaign runner
# --------------------------------------------------------------------------- #


def run_campaign(
    dry_run: bool = False,
    skip_sent: bool = True,
):
    """
    Main campaign loop.

    Args:
        dry_run:    If True, build messages but do NOT call the Gmail API.
        skip_sent:  If True, skip contacts already in the send log.
    """
    service = None if dry_run else get_gmail_service()

    # Get authenticated sender email
    sender_email = "me"
    if not dry_run:
        profile = service.users().getProfile(userId="me").execute()
        sender_email = profile["emailAddress"]
        log.info("Sending as: %s", sender_email)

    contacts = load_contacts(CONTACTS_CSV)
    already_sent = load_log(LOG_FILE) if skip_sent else set()

    template = TEMPLATE_FILE.read_text(encoding="utf-8")

    stats = {"sent": 0, "skipped": 0, "failed": 0}

    for contact in contacts:
        email = contact["email"].strip().lower()
        name = contact.get("name", "")
        company = contact.get("company", "")

        if email in already_sent:
            log.info("Skipping (already sent): %s", email)
            stats["skipped"] += 1
            continue

        # Personalise subject and body
        subject = SUBJECT.format(**contact)
        html_body = render_template(template, contact)

        # Look for a matching PDF: <email>.pdf or <company>.pdf
        pdf_path = None
        if ATTACHMENTS_DIR.exists():
            for candidate in [
                ATTACHMENTS_DIR / f"{email}.pdf",
                ATTACHMENTS_DIR / f"{company.lower().replace(' ', '_')}.pdf",
                ATTACHMENTS_DIR / "default.pdf",
            ]:
                if candidate.exists():
                    pdf_path = candidate
                    break

        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "email": email,
            "name": name,
            "company": company,
            "subject": subject,
            "attachment": pdf_path.name if pdf_path else "",
            "status": "",
            "error": "",
        }

        if dry_run:
            log.info("[DRY RUN] Would send to %s | subject: %s | pdf: %s", email, subject, pdf_path)
            record["status"] = "dry_run"
            append_log(LOG_FILE, record)
            stats["sent"] += 1
            continue

        try:
            message = build_message(sender_email, contact, html_body, subject, pdf_path)
            service.users().messages().send(userId="me", body=message).execute()
            log.info("Sent → %s (%s)", email, name)
            record["status"] = "sent"
            stats["sent"] += 1
        except HttpError as exc:
            log.error("Failed → %s: %s", email, exc)
            record["status"] = "failed"
            record["error"] = str(exc)
            stats["failed"] += 1
        except Exception as exc:  # noqa: BLE001
            log.error("Unexpected error for %s: %s", email, exc)
            record["status"] = "failed"
            record["error"] = str(exc)
            stats["failed"] += 1

        append_log(LOG_FILE, record)

    log.info(
        "Campaign complete. Sent: %d | Skipped: %d | Failed: %d",
        stats["sent"], stats["skipped"], stats["failed"],
    )
    return stats


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Gmail Campaign Sender")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Build and log emails without actually sending them.",
    )
    parser.add_argument(
        "--resend-all",
        action="store_true",
        help="Ignore the send log and resend to every contact.",
    )
    args = parser.parse_args()

    run_campaign(dry_run=args.dry_run, skip_sent=not args.resend_all)
